package plan;

import map.MapEdge;
import map.MapNode;
import java.util.*;
/**
 * A class defining planning using Best First Search
 */
public class GreedyBestFirstPlanner extends Planner {
    /**
     * heuristics used for Best First Search
     */
    Heuristic heuristic;

    /**
     * Initializer
     *
     * @param heuristic a heuristic object
     */
    public GreedyBestFirstPlanner(Heuristic heuristic) {
        super();
        //TODO
        this.heuristic = heuristic;
    }

    /**
     * Runs Best First Search
     *
     * @param startNode the start node
     * @param goalNode  the goal node
     * @return a list of MapNode objects
     */
    @Override
    public PlanResult plan(MapNode startNode, MapNode goalNode) {
        //TODO
        PriorityQueue<MapNode> pq = new PriorityQueue<>(Comparator.comparingDouble(n -> heuristic.getHeuristics(n, goalNode)));
        HashMap<MapNode, MapNode> parents = new HashMap<>();
        Set<MapNode> expandedNodes = new HashSet<>();
        pq.add(startNode);
        parents.put(startNode, null);
        while (!pq.isEmpty()) {
            MapNode node = pq.poll();
            expandedNodes.add(node);
            if (node.id == goalNode.id) {
                return new PlanResult(expandedNodes.size(), getNodeList(parents, goalNode));
            }
            for (MapEdge edge : node.edges) {
                MapNode nextNode = edge.destinationNode;
                if (!parents.containsKey(nextNode)) {
                    parents.put(nextNode, node);
                    pq.add(nextNode);
                }
            }
        }
        return new PlanResult(expandedNodes.size(), null);
    }

    /**
     * Gets the name of the planner
     *
     * @return planner name
     */
    @Override
    public String getName() {
        return getClass().getSimpleName();
    }
}

package plan;

import map.MapEdge;
import map.MapNode;
import java.util.*;
/**
 * A class defining planning using Uniform Cost Search
 */
public class UniformCostPlanner extends Planner {
    /**
     * heuristics used for Uniform Cost Search
     */
    CostFunction costFunction;

    /**
     * Initializer
     *
     * @param costFunction a costFunction object
     */
    public UniformCostPlanner(CostFunction costFunction) {
        super();
        //TODO
        this.costFunction = costFunction;
    }

    /**
     * Runs Uniform Cost Search
     *
     * @param startNode the start node
     * @param goalNode  the goal node
     * @return a list of MapNode objects
     */
    @Override
    public PlanResult plan(MapNode startNode, MapNode goalNode) {
        //TODO
        HashMap<MapNode, Double> gScore = new HashMap<>();
        HashMap<MapNode, MapNode> parents = new HashMap<>();
        PriorityQueue<MapNode> pq = new PriorityQueue<>(Comparator.comparingDouble(n -> gScore.get(n)));
        Set<MapNode> expandedNodes = new HashSet<>();

        gScore.put(startNode, 0.0);
        pq.add(startNode);

        while (!pq.isEmpty()) {
            MapNode node = pq.poll(); //get the lowest cost node
            expandedNodes.add(node);
            if (node.id == goalNode.id) {
                return new PlanResult(expandedNodes.size(), getNodeList(parents, goalNode));
            }

            for (MapEdge edge : node.edges) {
                MapNode nextNode = edge.destinationNode;
                double newCost = gScore.get(node) + costFunction.getCost(edge);

                if (!gScore.containsKey(nextNode) || newCost < gScore.get(nextNode)) {
                    gScore.put(nextNode, newCost);
                    parents.put(nextNode, node);
                    pq.add(nextNode);
                }
            }
        }

        return new PlanResult(expandedNodes.size(), null);
    }

    /**
     * Gets the name of the planner
     *
     * @return planner name
     */
    @Override
    public String getName() {
        return getClass().getSimpleName();
    }
}

